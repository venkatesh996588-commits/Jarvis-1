package com.jarvis.assistant.actions

import android.content.Context
import com.jarvis.assistant.ai.AiApiClient
import com.jarvis.assistant.ai.ConversationTurn
import com.jarvis.assistant.ai.IntentProcessor
import com.jarvis.assistant.ai.IntentType
import com.jarvis.assistant.ai.JarvisIntent
import com.jarvis.assistant.memory.MemoryRepository

/**
 * The single entry point from "I heard some text" to "here's what JARVIS says back".
 *
 * Flow:
 *  1. If a sensitive action is awaiting confirmation, check this transcript against it first.
 *  2. Otherwise run the transcript through [IntentProcessor].
 *  3. Sensitive intents are parked in [ConfirmationManager] instead of executed immediately.
 *  4. Structured intents are executed by [AndroidActionExecutor].
 *  5. GENERAL_QUESTION / UNKNOWN try the optional [AiApiClient]; otherwise a local canned reply.
 *  6. Every turn is written to [MemoryRepository] for context + history + frequency stats.
 */
class CommandRouter(
    context: Context,
    private val memory: MemoryRepository,
    private val aiApiClient: AiApiClient = AiApiClient()
) {
    private val intentProcessor = IntentProcessor()
    private val executor = AndroidActionExecutor(context, intentProcessor)
    val confirmationManager = ConfirmationManager()

    suspend fun handle(transcript: String): String {
        val pending = confirmationManager.pending.value

        if (pending != null) {
            return when {
                confirmationManager.isAffirmative(transcript) -> {
                    val cleared = pending.copy(requiresConfirmation = false)
                    confirmationManager.confirm()
                    runAndRecord(cleared)
                }
                confirmationManager.isNegative(transcript) -> {
                    confirmationManager.cancel()
                    "Understood. Cancelled.".also { recordTurn(transcript, it) }
                }
                else -> {
                    // Anything else while a confirmation is pending is treated as "no",
                    // rather than silently executing a sensitive action.
                    confirmationManager.cancel()
                    "I'll cancel that since I didn't get a clear yes.".also { recordTurn(transcript, it) }
                }
            }
        }

        val context7 = memory.recentContext(7)
        val intent = intentProcessor.process(transcript, context7)

        if (intent.requiresConfirmation) {
            confirmationManager.request(intent)
            val prompt = confirmationPrompt(intent)
            recordTurn(transcript, prompt)
            return prompt
        }

        return runAndRecord(intent, transcript)
    }

    private suspend fun runAndRecord(intent: JarvisIntent, transcriptOverride: String? = null): String {
        val transcript = transcriptOverride ?: intent.rawTranscript

        val response = when (intent.intentType) {
            IntentType.GENERAL_QUESTION, IntentType.UNKNOWN ->
                answerConversationally(intent, memory.recentContext(7))
            IntentType.DELETE_MEMORY -> {
                memory.deleteAllData()
                "All stored memory has been deleted."
            }
            else -> {
                val result = executor.execute(intent)
                memory.recordCommandUsage(intent.intentType.name, transcript)
                result.spokenResponse
            }
        }

        recordTurn(transcript, response)
        return response
    }

    private fun answerConversationally(intent: JarvisIntent, context: List<ConversationTurn>): String {
        val question = intent.target ?: intent.rawTranscript
        return try {
            if (aiApiClient.isConfigured) {
                aiApiClient.ask(question, context)
            } else {
                localFallbackAnswer(question)
            }
        } catch (e: Exception) {
            localFallbackAnswer(question)
        }
    }

    private fun localFallbackAnswer(question: String): String {
        return "I'm running in offline mode and can't answer general questions like that yet. " +
            "You can enable a cloud AI model in Settings, or ask me to open an app, search the web, " +
            "check your battery, or set an alarm."
    }

    private fun confirmationPrompt(intent: JarvisIntent): String = when (intent.intentType) {
        IntentType.MAKE_CALL -> "I need your confirmation before calling ${intent.target ?: "that contact"}. Should I go ahead?"
        IntentType.DELETE_MEMORY -> "This will permanently delete everything I remember about you. Should I go ahead?"
        else -> "I need your confirmation before performing that action."
    }

    private suspend fun recordTurn(userText: String, jarvisText: String) {
        memory.recordTurn(ConversationTurn(userText, jarvisText))
    }

    fun configureCloudAi(endpoint: String, apiKey: String) {
        aiApiClient.configure(endpoint, apiKey)
    }
}
