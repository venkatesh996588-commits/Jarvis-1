package com.jarvis.assistant.ui

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.ai.ConversationTurn
import com.jarvis.assistant.voice.ListeningState
import com.jarvis.assistant.voice.JarvisListenerService
import com.jarvis.assistant.voice.SpeechToTextManager
import com.jarvis.assistant.voice.TextToSpeechManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class JarvisUiState(
    val listeningState: ListeningState = ListeningState.IDLE,
    val isSpeaking: Boolean = false,
    val partialText: String = "",
    val history: List<ConversationTurn> = emptyList(),
    val continuousListeningEnabled: Boolean = false,
    val pendingConfirmationText: String? = null,
    val lastError: String? = null
)

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as JarvisApplication
    private val stt = SpeechToTextManager(application)
    private val tts = TextToSpeechManager(application) { speaking ->
        _uiState.value = _uiState.value.copy(isSpeaking = speaking)
    }

    private val _uiState = MutableStateFlow(JarvisUiState())
    val uiState: StateFlow<JarvisUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            app.commandRouter.confirmationManager.pending.collect { pending ->
                _uiState.value = _uiState.value.copy(
                    pendingConfirmationText = pending?.let { "Confirmation needed for: ${it.intentType.name}" }
                )
            }
        }
        viewModelScope.launch {
            app.memoryRepository.observeHistory().collect { history ->
                _uiState.value = _uiState.value.copy(history = history)
            }
        }
    }

    /** Single-shot listen, triggered by tapping the mic button. */
    fun onMicTapped() {
        if (_uiState.value.listeningState == ListeningState.LISTENING) {
            stt.stopListening()
            _uiState.value = _uiState.value.copy(listeningState = ListeningState.IDLE)
            return
        }
        tts.stop()
        stt.startListening(
            onPartial = { partial ->
                _uiState.value = _uiState.value.copy(partialText = partial, listeningState = ListeningState.LISTENING)
            },
            onFinalResult = { text ->
                _uiState.value = _uiState.value.copy(listeningState = ListeningState.PROCESSING, partialText = "")
                if (text.isNotBlank()) processCommand(text) else {
                    _uiState.value = _uiState.value.copy(listeningState = ListeningState.IDLE)
                }
            },
            onError = { message ->
                _uiState.value = _uiState.value.copy(listeningState = ListeningState.ERROR, lastError = message)
            }
        )
    }

    private fun processCommand(transcript: String) {
        viewModelScope.launch {
            val response = app.commandRouter.handle(transcript)
            _uiState.value = _uiState.value.copy(listeningState = ListeningState.IDLE)
            tts.speak(response)
        }
    }

    fun setContinuousListening(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(continuousListeningEnabled = enabled)
        viewModelScope.launch {
            app.memoryRepository.setPreference(
                com.jarvis.assistant.memory.MemoryRepository.KEY_CONTINUOUS_LISTENING,
                enabled.toString()
            )
        }
        val ctx = getApplication<Application>()
        val serviceIntent = Intent(ctx, JarvisListenerService::class.java)
        if (enabled) {
            androidx.core.content.ContextCompat.startForegroundService(ctx, serviceIntent)
        } else {
            ctx.stopService(serviceIntent)
        }
    }

    fun clearAllMemory() {
        viewModelScope.launch {
            app.memoryRepository.deleteAllData()
        }
    }

    override fun onCleared() {
        stt.stopListening()
        tts.shutdown()
        super.onCleared()
    }
}
