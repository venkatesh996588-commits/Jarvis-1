package com.jarvis.assistant.ai

/**
 * The structured "command" contract between the AI/NLU layer and the Android action layer.
 * Every recognized voice command is normalized into one of these before anything is executed.
 */
enum class IntentType {
    OPEN_APP,
    WEB_SEARCH,
    OPEN_SETTINGS,
    OPEN_WEBSITE,
    FLASHLIGHT,
    BATTERY_STATUS,
    DEVICE_INFO,
    MEDIA_CONTROL,
    CREATE_ALARM,
    CREATE_REMINDER,
    MAKE_CALL,
    DELETE_MEMORY,
    GENERAL_QUESTION,
    UNKNOWN
}

/**
 * target: the object of the action, e.g. app name, url, query text, contact name.
 * extras: free-form key/value data an action executor might need (e.g. alarm hour/minute).
 * requiresConfirmation: true for anything sensitive (calls, deleting data, security settings).
 * spokenResponse: what JARVIS should say. Filled in by the router/executor once the action
 *   result is known; the AI layer may pre-fill a provisional line for GENERAL_QUESTION.
 */
data class JarvisIntent(
    val intentType: IntentType,
    val target: String? = null,
    val extras: Map<String, String> = emptyMap(),
    val requiresConfirmation: Boolean = false,
    val spokenResponse: String? = null,
    val rawTranscript: String = ""
)

/** A single turn in the running conversation, kept in memory for context. */
data class ConversationTurn(
    val userText: String,
    val jarvisText: String,
    val timestampMillis: Long = System.currentTimeMillis()
)
