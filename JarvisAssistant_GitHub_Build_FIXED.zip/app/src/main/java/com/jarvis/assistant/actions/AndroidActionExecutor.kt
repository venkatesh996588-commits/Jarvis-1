package com.jarvis.assistant.actions

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import android.media.AudioManager
import com.jarvis.assistant.ai.IntentProcessor
import com.jarvis.assistant.ai.IntentType
import com.jarvis.assistant.ai.JarvisIntent

/** Result of executing an action: what JARVIS should say, and whether it succeeded. */
data class ActionResult(val spokenResponse: String, val success: Boolean)

/**
 * Executes a validated [JarvisIntent] against real Android APIs.
 * This class assumes the caller (CommandRouter) has already handled confirmation for
 * anything sensitive — it will still refuse to run MAKE_CALL/DELETE_MEMORY etc. if
 * [JarvisIntent.requiresConfirmation] is still true, as a defensive second check.
 */
class AndroidActionExecutor(
    private val context: Context,
    private val intentProcessor: IntentProcessor
) {
    private var flashlightOn = false

    fun execute(intent: JarvisIntent): ActionResult {
        // Defensive guard: sensitive intents must have been cleared by ConfirmationManager
        // before reaching here (requiresConfirmation flipped to false by the router).
        if (intent.requiresConfirmation && intent.intentType in SENSITIVE_TYPES) {
            return ActionResult("I need your confirmation before performing that action.", false)
        }

        return when (intent.intentType) {
            IntentType.OPEN_APP -> openApp(intent.target)
            IntentType.WEB_SEARCH -> webSearch(intent.target)
            IntentType.OPEN_WEBSITE -> openWebsite(intent.target)
            IntentType.OPEN_SETTINGS -> openSettings(intent.target)
            IntentType.FLASHLIGHT -> toggleFlashlight(intent.target)
            IntentType.BATTERY_STATUS -> batteryStatus()
            IntentType.DEVICE_INFO -> deviceInfo()
            IntentType.MEDIA_CONTROL -> mediaControl(intent.target)
            IntentType.CREATE_ALARM -> createAlarm(intent.extras)
            IntentType.CREATE_REMINDER -> createReminder(intent.target)
            IntentType.MAKE_CALL -> makeCall(intent.target)
            else -> ActionResult("I'm not able to do that yet.", false)
        }
    }

    private fun startActivitySafely(intent: Intent, failureMessage: String): ActionResult {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ActionResult("Done.", true)
        } catch (e: Exception) {
            ActionResult(failureMessage, false)
        }
    }

    private fun openApp(target: String?): ActionResult {
        if (target.isNullOrBlank()) return ActionResult("Which app should I open?", false)
        val pkg = intentProcessor.resolvePackageName(target)
        val launchIntent = pkg?.let { context.packageManager.getLaunchIntentForPackage(it) }

        if (launchIntent != null) {
            return startActivitySafely(launchIntent, "I couldn't open $target.")
        }

        // Fall back: try to find any installed app whose label matches the spoken name.
        val pm = context.packageManager
        val match = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().equals(target, ignoreCase = true)
        }
        val fallbackIntent = match?.let { pm.getLaunchIntentForPackage(it.packageName) }
        return if (fallbackIntent != null) {
            startActivitySafely(fallbackIntent, "I couldn't open $target.")
        } else {
            ActionResult("I couldn't find an app called $target.", false)
        }
    }

    private fun webSearch(query: String?): ActionResult {
        if (query.isNullOrBlank()) return ActionResult("What should I search for?", false)
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra("query", query)
        }
        return startActivitySafely(intent, "I couldn't run that search.")
    }

    private fun openWebsite(url: String?): ActionResult {
        if (url.isNullOrBlank()) return ActionResult("Which website should I open?", false)
        val normalized = if (!url.startsWith("http")) "https://$url" else url
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalized))
        return startActivitySafely(intent, "I couldn't open that website.")
    }

    private fun openSettings(page: String?): ActionResult {
        val action = when (page) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return startActivitySafely(Intent(action), "I couldn't open settings.")
    }

    private fun toggleFlashlight(target: String?): ActionResult {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        return try {
            val camId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return ActionResult("This device has no flashlight.", false)

            val turnOn = target != "off"
            cameraManager.setTorchMode(camId, turnOn)
            flashlightOn = turnOn
            ActionResult(if (turnOn) "The flashlight is now on." else "The flashlight is now off.", true)
        } catch (e: Exception) {
            ActionResult("I couldn't control the flashlight.", false)
        }
    }

    private fun batteryStatus(): ActionResult {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        val suffix = if (charging) " and charging" else ""
        return ActionResult("Your battery is at $level percent$suffix.", true)
    }

    private fun deviceInfo(): ActionResult {
        val info = "You're on ${Build.MANUFACTURER} ${Build.MODEL}, running Android ${Build.VERSION.RELEASE}."
        return ActionResult(info, true)
    }

    private fun mediaControl(action: String?): ActionResult {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val keyCode = when (action) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> null
        } ?: return ActionResult("I don't recognize that media command.", false)

        return try {
            audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
            ActionResult("Done.", true)
        } catch (e: Exception) {
            ActionResult("I couldn't control media playback.", false)
        }
    }

    private fun createAlarm(extras: Map<String, String>): ActionResult {
        val hour = extras["hour"]?.toIntOrNull()
        val minute = extras["minute"]?.toIntOrNull() ?: 0
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            if (hour != null) {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
            }
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }
        return startActivitySafely(intent, "I couldn't set that alarm.")
    }

    private fun createReminder(message: String?): ActionResult {
        // No universal cross-OEM reminder intent exists; hand off to the default
        // reminder/calendar app via a generic insert intent as the most portable option.
        val text = message ?: "Reminder"
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = android.provider.CalendarContract.Events.CONTENT_URI
            putExtra(android.provider.CalendarContract.Events.TITLE, text)
        }
        return startActivitySafely(intent, "I couldn't create that reminder.")
    }

    private fun makeCall(target: String?): ActionResult {
        if (target.isNullOrBlank()) return ActionResult("Who should I call?", false)
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(target)}"))
        return startActivitySafely(intent, "I couldn't place that call.")
    }

    companion object {
        val SENSITIVE_TYPES = setOf(IntentType.MAKE_CALL, IntentType.DELETE_MEMORY)
    }
}
