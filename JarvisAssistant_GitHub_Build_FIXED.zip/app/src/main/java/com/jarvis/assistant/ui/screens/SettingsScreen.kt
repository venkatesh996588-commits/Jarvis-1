@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.assistant.ui.JarvisBackground
import com.jarvis.assistant.ui.JarvisCyan
import com.jarvis.assistant.ui.JarvisDanger
import com.jarvis.assistant.ui.JarvisText
import com.jarvis.assistant.ui.JarvisViewModel

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenPermissions: () -> Unit,
    viewModel: JarvisViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = JarvisBackground,
        topBar = {
            TopAppBar(
                title = { Text("Settings", color = JarvisCyan, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = JarvisText)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = JarvisBackground)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
        ) {
            SettingRow(
                title = "Continuous \"Hey Jarvis\" listening",
                subtitle = "Runs a foreground service with a persistent notification. Uses more battery.",
            ) {
                Switch(
                    checked = uiState.continuousListeningEnabled,
                    onCheckedChange = { viewModel.setContinuousListening(it) }
                )
            }

            Spacer(Modifier.height(20.dp))

            TextButton(onClick = onOpenPermissions) {
                Text("Manage permissions", color = JarvisCyan)
            }

            Spacer(Modifier.height(20.dp))
            HorizontalDivider()
            Spacer(Modifier.height(20.dp))

            Text("Privacy & Data", color = JarvisText, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                "Commands are understood on-device by default. Nothing is sent to the " +
                    "internet unless you explicitly enable a cloud AI model for general " +
                    "conversation. JARVIS never collects passwords, OTPs, or banking details.",
                color = JarvisText
            )

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = { showDeleteConfirm = true },
                colors = ButtonDefaults.buttonColors(containerColor = JarvisDanger)
            ) {
                Text("Delete my data")
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete all data?") },
            text = { Text("This permanently removes your saved name, conversation history, and command usage stats. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.clearAllMemory()
                    showDeleteConfirm = false
                }) { Text("Delete", color = JarvisDanger) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, trailing: @Composable () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = JarvisText, fontWeight = FontWeight.Medium)
            Text(subtitle, color = com.jarvis.assistant.ui.JarvisTextDim, style = MaterialTheme.typography.bodySmall)
        }
        trailing()
    }
}
