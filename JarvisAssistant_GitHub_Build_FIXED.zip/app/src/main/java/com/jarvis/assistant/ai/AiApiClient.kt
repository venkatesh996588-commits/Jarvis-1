package com.jarvis.assistant.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Optional network fallback for GENERAL_QUESTION / UNKNOWN intents that the offline
 * IntentProcessor can't turn into a device action.
 *
 * Fully opt-in: if no endpoint/key is configured in Settings, [isConfigured] is false and
 * the caller (CommandRouter) should fall back to a canned local response instead. No data
 * leaves the device unless the user explicitly turns this on and provides their own
 * key — matching the "process data locally whenever possible" requirement.
 */
class AiApiClient(
    private var endpoint: String = "",
    private var apiKey: String = ""
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    val isConfigured: Boolean
        get() = endpoint.isNotBlank() && apiKey.isNotBlank()

    fun configure(newEndpoint: String, newApiKey: String) {
        endpoint = newEndpoint
        apiKey = newApiKey
    }

    /**
     * Sends the transcript plus recent conversation turns to a Messages-style API
     * (e.g. Anthropic's /v1/messages format) and returns the plain-text reply.
     * Throws IOException on any network/parse failure so the caller can degrade gracefully.
     */
    @Throws(IOException::class)
    fun ask(question: String, context: List<ConversationTurn>): String {
        if (!isConfigured) throw IOException("AI API not configured")

        val messages = JSONArray()
        context.takeLast(6).forEach { turn ->
            messages.put(JSONObject().put("role", "user").put("content", turn.userText))
            messages.put(JSONObject().put("role", "assistant").put("content", turn.jarvisText))
        }
        messages.put(JSONObject().put("role", "user").put("content", question))

        val body = JSONObject().apply {
            put("model", "claude-sonnet-4-6")
            put("max_tokens", 300)
            put("messages", messages)
            put("system", "You are JARVIS, a concise, calm, futuristic personal assistant. " +
                "Keep answers short and speakable aloud. Do not overuse the word 'sir'.")
        }

        val request = Request.Builder()
            .url(endpoint)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("AI API error: ${response.code}")
            val json = JSONObject(response.body?.string().orEmpty())
            val content = json.optJSONArray("content") ?: throw IOException("Malformed AI response")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") sb.append(block.optString("text"))
            }
            return sb.toString().ifBlank { throw IOException("Empty AI response") }
        }
    }
}
