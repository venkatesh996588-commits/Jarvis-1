package com.jarvis.assistant.voice

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.R
import com.jarvis.assistant.utils.Constants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Optional, user-toggled foreground service that keeps restarting on-device speech
 * recognition and watches for the wake phrase "Hey Jarvis". It always shows a
 * persistent notification while active — the assistant never listens invisibly.
 *
 * This is an MVP wake-word approach built entirely on Android's free SpeechRecognizer.
 * It is *not* as power-efficient as a dedicated offline wake-word engine (e.g. Picovoice
 * Porcupine) because each recognition pass briefly uses the mic and, on many OEMs, may
 * touch the network for the default recognizer. See README "Future Expansion" for how to
 * swap in a true low-power wake-word engine without changing the rest of the architecture.
 */
class JarvisListenerService : Service() {

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var stt: SpeechToTextManager
    private lateinit var tts: TextToSpeechManager
    private var running = false

    override fun onCreate() {
        super.onCreate()
        stt = SpeechToTextManager(this)
        tts = TextToSpeechManager(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(Constants.NOTIFICATION_ID, buildNotification())
        if (!running) {
            running = true
            listenLoop()
        }
        return START_STICKY
    }

    private fun listenLoop() {
        scope.launch {
            while (running) {
                val heard = awaitSingleUtterance()
                if (heard != null) {
                    val lower = heard.lowercase()
                    if (lower.contains(Constants.WAKE_WORD) || lower.contains(Constants.WAKE_WORD_ALT)) {
                        val command = lower
                            .substringAfter(Constants.WAKE_WORD, "")
                            .ifBlank { lower.substringAfter(Constants.WAKE_WORD_ALT, "") }
                            .trim()

                        if (command.isNotEmpty()) {
                            handleCommand(command)
                        } else {
                            tts.speak("Yes?")
                            val follow = awaitSingleUtterance()
                            if (!follow.isNullOrBlank()) handleCommand(follow)
                        }
                    }
                }
                delay(300) // brief pause before restarting recognition
            }
        }
    }

    private suspend fun handleCommand(command: String) {
        val app = application as JarvisApplication
        val response = app.commandRouter.handle(command)
        tts.speak(response)
    }

    private suspend fun awaitSingleUtterance(): String? =
        kotlinx.coroutines.suspendCancellableCoroutine { cont ->
            stt.startListening(
                onFinalResult = { text -> if (cont.isActive) cont.resume(text.ifBlank { null }) {} },
                onError = { if (cont.isActive) cont.resume(null) {} }
            )
        }

    private fun buildNotification() = NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_ID)
        .setContentTitle(getString(R.string.listening_notification_title))
        .setContentText(getString(R.string.listening_notification_text))
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setOngoing(true)
        .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                Constants.NOTIFICATION_CHANNEL_ID,
                "JARVIS Listening",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        running = false
        stt.stopListening()
        tts.shutdown()
        scope.launch { }.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
