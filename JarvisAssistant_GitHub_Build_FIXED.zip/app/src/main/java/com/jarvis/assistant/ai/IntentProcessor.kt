package com.jarvis.assistant.ai

import org.json.JSONObject

/**
 * Turns a raw transcript into a JarvisIntent.
 *
 * This is a lightweight, fully-offline, rule-based NLU layer so the assistant works with
 * zero network dependency and zero API cost out of the box. It understands English, Tamil
 * (romanized "Tanglish" and native script keywords), and mixed sentences.
 *
 * [AiApiClient] can optionally be wired in later as a smarter fallback for anything this
 * layer classifies as GENERAL_QUESTION or UNKNOWN — see CommandRouter.
 */
class IntentProcessor {

    // Keyword sets are intentionally simple substring checks so this stays fast, offline,
    // and easy for contributors to extend with more languages/phrasings.
    private val openWords = listOf("open", "launch", "start", "திற", "start பண்ணு", "podunga", "podu")
    private val searchWords = listOf("search", "google", "find", "தேடு", "search pannu")
    private val flashlightOnWords = listOf("flashlight on", "torch on", "light on", "vilakku on", "torch podu")
    private val flashlightOffWords = listOf("flashlight off", "torch off", "light off", "vilakku off", "torch nikku")
    private val batteryWords = listOf("battery", "charge", "பேட்டரி", "battery ethana")
    private val deviceInfoWords = listOf("device info", "phone info", "storage", "ram", "model number")
    private val callWords = listOf("call ", "phone ", "அழை", "call pannu")
    private val alarmWords = listOf("alarm", "wake me", "அலாரம்")
    private val reminderWords = listOf("remind me", "reminder", "நினைவூட்டு")
    private val settingsWords = listOf("settings", "wifi settings", "bluetooth settings", "setting")
    private val mediaPlayWords = listOf("play music", "resume", "play pannu")
    private val mediaPauseWords = listOf("pause", "stop music", "நிறுத்து", "stop pannu")
    private val mediaNextWords = listOf("next song", "skip")
    private val mediaPrevWords = listOf("previous song", "last song")
    private val deleteMemoryWords = listOf("delete my data", "forget everything", "clear memory", "delete memory")

    private val knownApps = mapOf(
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps",
        "whatsapp" to "com.whatsapp",
        "gmail" to "com.google.android.gm",
        "camera" to null, // resolved via system camera intent in executor
        "settings" to null,
        "calendar" to "com.google.android.calendar",
        "spotify" to "com.spotify.music",
        "phone" to null,
        "message" to null,
        "messages" to null
    )

    fun process(transcript: String, conversationContext: List<ConversationTurn>): JarvisIntent {
        val text = transcript.trim().lowercase()
        if (text.isEmpty()) return unknown(transcript)

        // Highest-risk intents checked first, and explicitly flagged for confirmation.
        for (w in callWords) {
            if (text.contains(w)) {
                val name = text.substringAfter(w).trim().ifEmpty { null }
                return JarvisIntent(
                    intentType = IntentType.MAKE_CALL,
                    target = name,
                    requiresConfirmation = true,
                    rawTranscript = transcript
                )
            }
        }
        if (deleteMemoryWords.any { text.contains(it) }) {
            return JarvisIntent(
                intentType = IntentType.DELETE_MEMORY,
                requiresConfirmation = true,
                rawTranscript = transcript
            )
        }

        for (w in flashlightOnWords) if (text.contains(w)) return JarvisIntent(IntentType.FLASHLIGHT, "on", rawTranscript = transcript)
        for (w in flashlightOffWords) if (text.contains(w)) return JarvisIntent(IntentType.FLASHLIGHT, "off", rawTranscript = transcript)

        if (batteryWords.any { text.contains(it) }) return JarvisIntent(IntentType.BATTERY_STATUS, rawTranscript = transcript)
        if (deviceInfoWords.any { text.contains(it) }) return JarvisIntent(IntentType.DEVICE_INFO, rawTranscript = transcript)

        for (w in mediaPlayWords) if (text.contains(w)) return JarvisIntent(IntentType.MEDIA_CONTROL, "play", rawTranscript = transcript)
        for (w in mediaPauseWords) if (text.contains(w)) return JarvisIntent(IntentType.MEDIA_CONTROL, "pause", rawTranscript = transcript)
        for (w in mediaNextWords) if (text.contains(w)) return JarvisIntent(IntentType.MEDIA_CONTROL, "next", rawTranscript = transcript)
        for (w in mediaPrevWords) if (text.contains(w)) return JarvisIntent(IntentType.MEDIA_CONTROL, "previous", rawTranscript = transcript)

        if (alarmWords.any { text.contains(it) }) {
            val time = extractTime(text)
            return JarvisIntent(
                intentType = IntentType.CREATE_ALARM,
                extras = time?.let { mapOf("hour" to it.first.toString(), "minute" to it.second.toString()) } ?: emptyMap(),
                rawTranscript = transcript
            )
        }
        if (reminderWords.any { text.contains(it) }) {
            val message = reminderWords.firstOrNull { text.contains(it) }
                ?.let { text.substringAfter(it).trim() }
                ?.ifEmpty { null }
            return JarvisIntent(IntentType.CREATE_REMINDER, target = message, rawTranscript = transcript)
        }

        if (settingsWords.any { text.contains(it) }) {
            val page = when {
                text.contains("wifi") -> "wifi"
                text.contains("bluetooth") -> "bluetooth"
                text.contains("display") -> "display"
                text.contains("sound") -> "sound"
                else -> "general"
            }
            return JarvisIntent(IntentType.OPEN_SETTINGS, target = page, rawTranscript = transcript)
        }

        if (text.startsWith("open ") || text.startsWith("go to ") || openWords.any { text.contains(it) }) {
            val appName = extractAppName(text)
            if (appName != null) {
                return JarvisIntent(IntentType.OPEN_APP, target = appName, rawTranscript = transcript)
            }
        }

        if (text.contains("http") || text.contains(".com") || text.contains(".in") || text.contains("website")) {
            val url = extractUrl(text)
            if (url != null) return JarvisIntent(IntentType.OPEN_WEBSITE, target = url, rawTranscript = transcript)
        }

        for (w in searchWords) {
            if (text.contains(w)) {
                val query = text.substringAfter(w).trim().removePrefix("for").trim()
                return JarvisIntent(IntentType.WEB_SEARCH, target = query.ifEmpty { text }, rawTranscript = transcript)
            }
        }

        // No structured action matched -> treat as a conversational question.
        return JarvisIntent(IntentType.GENERAL_QUESTION, target = transcript, rawTranscript = transcript)
    }

    private fun extractAppName(text: String): String? {
        val stripped = openWords.fold(text) { acc, w -> acc.replace(w, "") }.trim()
        val candidate = stripped.removePrefix("go to").trim()
        return knownApps.keys.firstOrNull { candidate.contains(it) } ?: candidate.ifEmpty { null }
    }

    fun resolvePackageName(appTarget: String): String? = knownApps[appTarget.lowercase()]

    private fun extractUrl(text: String): String? {
        val regex = Regex("""(https?://\S+|\S+\.(com|in|org|net)\S*)""")
        return regex.find(text)?.value
    }

    /** Very small "at 7", "at 7:30", "at 7 am" parser. Returns hour(0-23) to minute. */
    private fun extractTime(text: String): Pair<Int, Int>? {
        val regex = Regex("""(\d{1,2})(:(\d{2}))?\s*(am|pm)?""")
        val match = regex.find(text) ?: return null
        var hour = match.groupValues[1].toIntOrNull() ?: return null
        val minute = match.groupValues[3].toIntOrNull() ?: 0
        val meridiem = match.groupValues[4]
        if (meridiem == "pm" && hour < 12) hour += 12
        if (meridiem == "am" && hour == 12) hour = 0
        return hour to minute
    }

    private fun unknown(raw: String) = JarvisIntent(IntentType.UNKNOWN, rawTranscript = raw)

    /** Structured JSON representation used internally (logging, debugging, future cloud calls). */
    fun toJson(intent: JarvisIntent): String {
        val obj = JSONObject()
        obj.put("intent", intent.intentType.name.lowercase())
        obj.put("target", intent.target ?: JSONObject.NULL)
        obj.put("requires_confirmation", intent.requiresConfirmation)
        val extras = JSONObject()
        intent.extras.forEach { (k, v) -> extras.put(k, v) }
        obj.put("extras", extras)
        return obj.toString()
    }
}
