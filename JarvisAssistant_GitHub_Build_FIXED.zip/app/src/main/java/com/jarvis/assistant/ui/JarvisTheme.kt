package com.jarvis.assistant.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val JarvisCyan = Color(0xFF00E5FF)
val JarvisCyanDim = Color(0xFF0097A7)
val JarvisAmber = Color(0xFFFFB300)
val JarvisBackground = Color(0xFF0A0E14)
val JarvisSurface = Color(0xFF111826)
val JarvisText = Color(0xFFE6F7FF)
val JarvisTextDim = Color(0xFF7FA8B8)
val JarvisDanger = Color(0xFFFF5252)

private val JarvisColorScheme = darkColorScheme(
    primary = JarvisCyan,
    secondary = JarvisAmber,
    background = JarvisBackground,
    surface = JarvisSurface,
    onPrimary = JarvisBackground,
    onBackground = JarvisText,
    onSurface = JarvisText,
    error = JarvisDanger
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        content = content
    )
}
