package com.jarvis.assistant.utils

object Constants {
    const val WAKE_WORD = "hey jarvis"
    const val WAKE_WORD_ALT = "hey jarvish" // common misrecognition
    const val NOTIFICATION_CHANNEL_ID = "jarvis_listener_channel"
    const val NOTIFICATION_ID = 42
}
