package com.jarvis.assistant.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.JarvisCyan
import com.jarvis.assistant.ui.JarvisCyanDim
import com.jarvis.assistant.voice.ListeningState
import kotlin.math.sin
import kotlin.random.Random

/**
 * The central "AI core": a pulsing ring that speeds up while listening and shows a
 * gentle rotating sweep while processing.
 */
@Composable
fun AiCore(state: ListeningState, isSpeaking: Boolean, modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "core")

    val pulse by infinite.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (state == ListeningState.LISTENING || isSpeaking) 550 else 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (state == ListeningState.PROCESSING) 900 else 6000, easing = LinearEasing)
        ),
        label = "rotation"
    )

    Box(modifier = modifier.size(220.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
        Canvas(modifier = Modifier.size(220.dp)) {
            val ringColor = if (state == ListeningState.ERROR) JarvisCyanDim else JarvisCyan
            val radius = size.minDimension / 2f * pulse

            // Outer glow ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(ringColor.copy(alpha = 0.25f), androidx.compose.ui.graphics.Color.Transparent),
                    radius = radius * 1.4f
                ),
                radius = radius * 1.4f
            )

            // Rotating arc sweep (denotes "thinking")
            rotate(rotation) {
                drawArc(
                    color = ringColor,
                    startAngle = 0f,
                    sweepAngle = 100f,
                    useCenter = false,
                    style = Stroke(width = 6f)
                )
            }

            // Core ring
            drawCircle(
                color = ringColor,
                radius = radius * 0.62f,
                style = Stroke(width = 4f)
            )

            // Inner solid dot
            drawCircle(
                color = ringColor,
                radius = radius * 0.12f,
                center = Offset(size.width / 2f, size.height / 2f)
            )
        }
    }
}

/** Horizontal glowing waveform, active while listening. */
@Composable
fun Waveform(active: Boolean, modifier: Modifier = Modifier, barCount: Int = 24) {
    val infinite = rememberInfiniteTransition(label = "waveform")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(animation = tween(1200, easing = LinearEasing)),
        label = "phase"
    )
    val seeds = remember { List(barCount) { Random.nextFloat() * 2f + 0.5f } }

    Canvas(modifier = modifier) {
        val barWidth = size.width / (barCount * 1.6f)
        val gap = barWidth * 0.6f
        for (i in 0 until barCount) {
            val amplitude = if (active) {
                (sin(phase + i * 0.5f) * 0.5f + 0.5f) * seeds[i]
            } else {
                0.08f
            }
            val barHeight = (size.height * 0.1f) + amplitude * size.height * 0.4f
            val x = i * (barWidth + gap)
            drawLine(
                color = JarvisCyan.copy(alpha = if (active) 0.9f else 0.3f),
                start = Offset(x, size.height / 2f - barHeight / 2f),
                end = Offset(x, size.height / 2f + barHeight / 2f),
                strokeWidth = barWidth,
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }
    }
}
