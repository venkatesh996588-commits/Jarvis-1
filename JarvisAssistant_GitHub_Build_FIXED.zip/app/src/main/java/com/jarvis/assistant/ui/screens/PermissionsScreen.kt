@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.jarvis.assistant.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.JarvisBackground
import com.jarvis.assistant.ui.JarvisCyan
import com.jarvis.assistant.ui.JarvisDanger
import com.jarvis.assistant.ui.JarvisText
import com.jarvis.assistant.ui.JarvisTextDim
import com.jarvis.assistant.utils.PermissionUtils

private data class PermissionRowData(val permission: String, val label: String)

private val TRACKED_PERMISSIONS = listOf(
    PermissionRowData(Manifest.permission.RECORD_AUDIO, "Microphone"),
    PermissionRowData(Manifest.permission.CAMERA, "Camera (flashlight only)"),
    PermissionRowData(Manifest.permission.CALL_PHONE, "Phone calls (confirmed only)")
)

@Composable
fun PermissionsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var refreshKey by remember { mutableStateOf(0) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        refreshKey++
    }

    Scaffold(
        containerColor = JarvisBackground,
        topBar = {
            TopAppBar(
                title = { Text("Permissions", color = JarvisCyan, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = JarvisText)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = JarvisBackground)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "JARVIS only requests what each feature needs, when it needs it, and never hides what a permission is for.",
                    color = JarvisTextDim
                )
            }
            items(TRACKED_PERMISSIONS) { row ->
                key(refreshKey) {
                    val granted = PermissionUtils.hasPermission(context, row.permission)
                    PermissionCard(
                        label = row.label,
                        explanation = PermissionUtils.explanationFor(row.permission),
                        granted = granted,
                        onRequest = { launcher.launch(row.permission) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionCard(label: String, explanation: String, granted: Boolean, onRequest: () -> Unit) {
    Card {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Icon(
                    imageVector = if (granted) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                    contentDescription = null,
                    tint = if (granted) JarvisCyan else JarvisDanger
                )
                Spacer(Modifier.width(8.dp))
                Text(label, color = JarvisText, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.height(6.dp))
            Text(explanation, color = JarvisTextDim, style = MaterialTheme.typography.bodySmall)
            if (!granted) {
                Spacer(Modifier.height(10.dp))
                Button(onClick = onRequest) { Text("Grant") }
            }
        }
    }
}
