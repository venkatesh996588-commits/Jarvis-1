package com.jarvis.assistant.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

object PermissionUtils {

    /** Permissions requested up front for core voice functionality. */
    val CORE_PERMISSIONS = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.CAMERA) // required by CameraManager for flashlight torch mode
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    /** Requested separately, only right before the relevant action, per least-privilege. */
    const val CALL_PERMISSION = Manifest.permission.CALL_PHONE

    fun hasPermission(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun hasAllCorePermissions(context: Context): Boolean =
        CORE_PERMISSIONS.all { hasPermission(context, it) }

    fun missingCorePermissions(context: Context): List<String> =
        CORE_PERMISSIONS.filterNot { hasPermission(context, it) }

    /** Human-readable explanation shown before each permission request, per "never hide permissions". */
    fun explanationFor(permission: String): String = when (permission) {
        Manifest.permission.RECORD_AUDIO -> "Microphone access is needed so JARVIS can hear your voice commands."
        Manifest.permission.CAMERA -> "Camera access is needed only to control the flashlight (torch)."
        Manifest.permission.CALL_PHONE -> "Phone access is needed to place a call after you confirm it."
        Manifest.permission.POST_NOTIFICATIONS -> "Notification access is used to show the listening indicator while JARVIS runs in the background."
        else -> "This permission is required for the requested action."
    }
}
