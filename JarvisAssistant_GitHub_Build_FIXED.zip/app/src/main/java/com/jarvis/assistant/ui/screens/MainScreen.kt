@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.assistant.ui.JarvisBackground
import com.jarvis.assistant.ui.JarvisCyan
import com.jarvis.assistant.ui.JarvisDanger
import com.jarvis.assistant.ui.JarvisText
import com.jarvis.assistant.ui.JarvisTextDim
import com.jarvis.assistant.ui.JarvisViewModel
import com.jarvis.assistant.ui.components.AiCore
import com.jarvis.assistant.ui.components.CommandHistoryView
import com.jarvis.assistant.ui.components.Waveform
import com.jarvis.assistant.voice.ListeningState

@Composable
fun MainScreen(
    onOpenSettings: () -> Unit,
    viewModel: JarvisViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        containerColor = JarvisBackground,
        topBar = {
            TopAppBar(
                title = { Text("JARVIS", color = JarvisCyan, fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = JarvisText)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = JarvisBackground)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(JarvisBackground)
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(12.dp))

            AiCore(state = uiState.listeningState, isSpeaking = uiState.isSpeaking)

            Spacer(Modifier.height(8.dp))

            Waveform(
                active = uiState.listeningState == ListeningState.LISTENING || uiState.isSpeaking,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = statusText(uiState),
                color = JarvisTextDim,
                modifier = Modifier.height(24.dp)
            )

            uiState.pendingConfirmationText?.let {
                Text(
                    text = "⚠ $it — say \"yes\" to confirm or \"no\" to cancel",
                    color = JarvisDanger,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            uiState.lastError?.let {
                Text(text = it, color = JarvisDanger, modifier = Modifier.padding(vertical = 4.dp))
            }

            Spacer(Modifier.height(12.dp))

            CommandHistoryView(
                history = uiState.history,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )

            Spacer(Modifier.height(12.dp))

            FloatingActionButton(
                onClick = { viewModel.onMicTapped() },
                containerColor = if (uiState.listeningState == ListeningState.LISTENING) JarvisDanger else JarvisCyan,
                contentColor = JarvisBackground
            ) {
                Icon(
                    imageVector = if (uiState.listeningState == ListeningState.LISTENING) Icons.Filled.MicOff else Icons.Filled.Mic,
                    contentDescription = "Talk to JARVIS"
                )
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

private fun statusText(uiState: com.jarvis.assistant.ui.JarvisUiState): String = when {
    uiState.isSpeaking -> "Speaking..."
    uiState.listeningState == ListeningState.LISTENING -> uiState.partialText.ifBlank { "Listening..." }
    uiState.listeningState == ListeningState.PROCESSING -> "Thinking..."
    uiState.listeningState == ListeningState.ERROR -> "Tap the mic to try again."
    else -> "Tap the mic or say \"Hey Jarvis\""
}
