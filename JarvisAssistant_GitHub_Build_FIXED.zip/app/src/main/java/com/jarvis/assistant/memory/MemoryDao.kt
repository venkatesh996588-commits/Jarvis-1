package com.jarvis.assistant.memory

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {

    @Query("SELECT * FROM preferences WHERE `key` = :key LIMIT 1")
    suspend fun getPreference(key: String): PreferenceEntity?

    @Query("SELECT * FROM preferences ORDER BY `key` ASC")
    fun observePreferences(): Flow<List<PreferenceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setPreference(pref: PreferenceEntity)

    @Query("DELETE FROM preferences WHERE `key` = :key")
    suspend fun deletePreference(key: String)

    @Insert
    suspend fun insertTurn(turn: ConversationTurnEntity)

    @Query("SELECT * FROM conversation_turns ORDER BY id DESC LIMIT :limit")
    fun observeRecentTurns(limit: Int = 50): Flow<List<ConversationTurnEntity>>

    @Query("SELECT * FROM conversation_turns ORDER BY id DESC LIMIT :limit")
    suspend fun getRecentTurns(limit: Int = 10): List<ConversationTurnEntity>

    @Query("DELETE FROM conversation_turns")
    suspend fun clearTurns()

    @Query("SELECT * FROM command_usage WHERE commandKey = :key LIMIT 1")
    suspend fun getUsage(key: String): CommandUsageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertUsage(usage: CommandUsageEntity)

    @Query("SELECT * FROM command_usage ORDER BY useCount DESC LIMIT :limit")
    fun observeTopCommands(limit: Int = 10): Flow<List<CommandUsageEntity>>

    @Query("DELETE FROM command_usage")
    suspend fun clearUsage()

    @Query("DELETE FROM preferences")
    suspend fun clearPreferences()

    @Transaction
    suspend fun deleteAllData() {
        clearTurns()
        clearUsage()
        clearPreferences()
    }
}
