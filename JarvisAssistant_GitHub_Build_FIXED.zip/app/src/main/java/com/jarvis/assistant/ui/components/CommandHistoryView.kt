package com.jarvis.assistant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ai.ConversationTurn
import com.jarvis.assistant.ui.JarvisSurface
import com.jarvis.assistant.ui.JarvisText
import com.jarvis.assistant.ui.JarvisTextDim
import com.jarvis.assistant.ui.JarvisCyan

@Composable
fun CommandHistoryView(history: List<ConversationTurn>, modifier: Modifier = Modifier) {
    if (history.isEmpty()) {
        Box(modifier = modifier, contentAlignment = androidx.compose.ui.Alignment.Center) {
            Text("Say \"Hey Jarvis\" or tap the mic to begin.", color = JarvisTextDim)
        }
        return
    }
    LazyColumn(
        modifier = modifier,
        reverseLayout = true,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(history.reversed()) { turn ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(JarvisSurface, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Text("You: ${turn.userText}", color = JarvisText, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(4.dp))
                Text("JARVIS: ${turn.jarvisText}", color = JarvisCyan)
            }
        }
    }
}
