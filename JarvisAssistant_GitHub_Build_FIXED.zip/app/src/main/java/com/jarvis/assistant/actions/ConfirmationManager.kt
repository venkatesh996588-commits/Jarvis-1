package com.jarvis.assistant.actions

import com.jarvis.assistant.ai.JarvisIntent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Holds a single pending sensitive intent (call, delete data, etc.) until the user
 * explicitly says or taps "yes"/"confirm". Nothing sensitive ever executes without
 * passing through here first.
 */
class ConfirmationManager {
    private val _pending = MutableStateFlow<JarvisIntent?>(null)
    val pending: StateFlow<JarvisIntent?> = _pending

    fun request(intent: JarvisIntent) {
        _pending.value = intent
    }

    fun confirm(): JarvisIntent? {
        val intent = _pending.value
        _pending.value = null
        return intent
    }

    fun cancel() {
        _pending.value = null
    }

    fun isAffirmative(text: String): Boolean {
        val t = text.trim().lowercase()
        return listOf("yes", "confirm", "do it", "go ahead", "sure", "ok", "okay", "ஆமா", "சரி").any { t.contains(it) }
    }

    fun isNegative(text: String): Boolean {
        val t = text.trim().lowercase()
        return listOf("no", "cancel", "stop", "don't", "dont", "இல்ல", "வேண்டாம்").any { t.contains(it) }
    }
}
