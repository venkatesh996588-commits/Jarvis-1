package com.jarvis.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/**
 * Wraps Android's built-in [TextToSpeech] engine to give JARVIS a voice.
 * A slightly lowered pitch + measured speech rate is used to approximate a calm,
 * synthetic "JARVIS" tone without requiring any paid voice API.
 */
class TextToSpeechManager(
    context: Context,
    private val onSpeakingStateChanged: (Boolean) -> Unit = {}
) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pendingQueue = mutableListOf<String>()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.setPitch(0.92f)
                tts?.setSpeechRate(1.02f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = onSpeakingStateChanged(true)
                    override fun onDone(utteranceId: String?) = onSpeakingStateChanged(false)
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = onSpeakingStateChanged(false)
                })
                ready = true
                pendingQueue.forEach { speakInternal(it) }
                pendingQueue.clear()
            }
        }
    }

    fun setLanguage(locale: Locale) {
        // Falls back silently to default voice if the Tamil TTS voice pack isn't installed;
        // callers should prompt the user to install it from Settings > Text-to-speech.
        tts?.language = locale
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        if (!ready) {
            pendingQueue.add(text)
            return
        }
        speakInternal(text)
    }

    private fun speakInternal(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
