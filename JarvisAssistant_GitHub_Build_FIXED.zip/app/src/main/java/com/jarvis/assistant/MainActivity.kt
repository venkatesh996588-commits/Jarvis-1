package com.jarvis.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jarvis.assistant.ui.JarvisTheme
import com.jarvis.assistant.ui.screens.MainScreen
import com.jarvis.assistant.ui.screens.PermissionsScreen
import com.jarvis.assistant.ui.screens.SettingsScreen
import com.jarvis.assistant.utils.PermissionUtils

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JarvisTheme {
                val launcher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestMultiplePermissions()
                ) { /* PermissionsScreen re-checks status live; nothing else needed here. */ }

                LaunchedEffect(Unit) {
                    val missing = PermissionUtils.missingCorePermissions(this@MainActivity)
                    if (missing.isNotEmpty()) {
                        launcher.launch(missing.toTypedArray())
                    }
                }

                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "main") {
                    composable("main") {
                        MainScreen(onOpenSettings = { navController.navigate("settings") })
                    }
                    composable("settings") {
                        SettingsScreen(
                            onBack = { navController.popBackStack() },
                            onOpenPermissions = { navController.navigate("permissions") }
                        )
                    }
                    composable("permissions") {
                        PermissionsScreen(onBack = { navController.popBackStack() })
                    }
                }
            }
        }
    }
}
