package com.jarvis.assistant.memory

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Simple key/value store for preferences like the user's preferred name. */
@Entity(tableName = "preferences")
data class PreferenceEntity(
    @PrimaryKey val key: String,
    val value: String
)

/** One remembered conversation turn, kept for short-term context and history display. */
@Entity(tableName = "conversation_turns")
data class ConversationTurnEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userText: String,
    val jarvisText: String,
    val timestampMillis: Long
)

/** Frequency counter for commands, to power "frequently used commands". */
@Entity(tableName = "command_usage")
data class CommandUsageEntity(
    @PrimaryKey val commandKey: String,
    val displayText: String,
    val useCount: Int,
    val lastUsedMillis: Long
)
