package com.jarvis.assistant

import android.app.Application
import com.jarvis.assistant.actions.CommandRouter
import com.jarvis.assistant.memory.MemoryRepository

/**
 * Holds the app-wide singletons so both the UI (MainActivity/ViewModel) and the background
 * JarvisListenerService share the same memory + router instead of duplicating state.
 */
class JarvisApplication : Application() {
    lateinit var memoryRepository: MemoryRepository
        private set
    lateinit var commandRouter: CommandRouter
        private set

    override fun onCreate() {
        super.onCreate()
        memoryRepository = MemoryRepository(this)
        commandRouter = CommandRouter(this, memoryRepository)
    }
}
