package com.jarvis.assistant.memory

import android.content.Context
import com.jarvis.assistant.ai.ConversationTurn
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Everything the assistant "remembers" lives behind this single class so it's easy to
 * audit, and easy to wipe completely via [deleteAllData] for the required
 * "Delete my data" control.
 */
class MemoryRepository(context: Context) {
    private val dao = MemoryDatabase.getInstance(context).dao()

    companion object {
        const val KEY_PREFERRED_NAME = "preferred_name"
        const val KEY_CONTINUOUS_LISTENING = "continuous_listening_enabled"
        const val KEY_LANGUAGE = "preferred_language" // en / ta / tanglish-auto
    }

    suspend fun getPreferredName(): String? = dao.getPreference(KEY_PREFERRED_NAME)?.value

    suspend fun setPreferredName(name: String) =
        dao.setPreference(PreferenceEntity(KEY_PREFERRED_NAME, name))

    suspend fun getPreference(key: String): String? = dao.getPreference(key)?.value

    suspend fun setPreference(key: String, value: String) =
        dao.setPreference(PreferenceEntity(key, value))

    fun observePreferences(): Flow<List<PreferenceEntity>> = dao.observePreferences()

    suspend fun recordTurn(turn: ConversationTurn) {
        dao.insertTurn(
            ConversationTurnEntity(
                userText = turn.userText,
                jarvisText = turn.jarvisText,
                timestampMillis = turn.timestampMillis
            )
        )
    }

    suspend fun recentContext(limit: Int = 10): List<ConversationTurn> =
        dao.getRecentTurns(limit).reversed().map {
            ConversationTurn(it.userText, it.jarvisText, it.timestampMillis)
        }

    fun observeHistory(limit: Int = 50): Flow<List<ConversationTurn>> =
        dao.observeRecentTurns(limit).map { list ->
            list.map { ConversationTurn(it.userText, it.jarvisText, it.timestampMillis) }
        }

    suspend fun recordCommandUsage(commandKey: String, displayText: String) {
        val existing = dao.getUsage(commandKey)
        dao.upsertUsage(
            CommandUsageEntity(
                commandKey = commandKey,
                displayText = displayText,
                useCount = (existing?.useCount ?: 0) + 1,
                lastUsedMillis = System.currentTimeMillis()
            )
        )
    }

    fun observeFrequentCommands(limit: Int = 10): Flow<List<CommandUsageEntity>> =
        dao.observeTopCommands(limit)

    suspend fun deletePreference(key: String) = dao.deletePreference(key)

    /** Full wipe — required "Delete my data" control. */
    suspend fun deleteAllData() = dao.deleteAllData()
}
