# JARVIS Mobile - GitHub Build

This copy adds a GitHub Actions workflow that builds a debug APK in the cloud.

## Mobile-only build
1. Upload this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build JARVIS APK**.
4. Tap **Run workflow**.
5. Wait for the build to finish.
6. Open the successful workflow run and download the `jarvis-debug-apk` artifact.
7. Extract the APK and install it on your Android phone.

## Important
This workflow expects the project to contain a working Gradle wrapper (`gradlew` plus `gradle/wrapper/gradle-wrapper.jar`).
If the original ZIP does not contain the wrapper JAR, GitHub Actions will fail at the Gradle step. In that case, the project must first be regenerated with a complete Gradle wrapper or built with a compatible hosted Android build environment.

Never put API keys, passwords, OTPs, or other secrets directly into the repository.
