# JARVIS — Android Voice Assistant (MVP)

A voice-controlled Android assistant: say **"Hey Jarvis"**, speak a command, and it executes
real on-device actions (open apps, search the web, control the flashlight, read battery
status, set alarms, and more) and replies out loud.

This is a genuinely working project, not a mockup — every action in the MVP list actually
calls the real Android API (CameraManager, SpeechRecognizer, TextToSpeech, PackageManager,
BatteryManager, Settings intents, AlarmClock intent, etc.).

---

## 1. What's implemented right now (MVP)

- **Wake word**: "Hey Jarvis" (+ common mis-hearing "Hey Jarvish"), via an optional
  foreground listening service, plus a manual mic button for tap-to-talk.
- **Speech-to-text**: Android's on-device `SpeechRecognizer` (English + Tamil locale support).
- **Text-to-speech**: Android's built-in `TextToSpeech` engine, tuned for a calmer, measured tone.
- **Intent understanding**: offline, rule-based NLU (`IntentProcessor`) that understands
  English, Tamil, and Tanglish keywords, with an optional pluggable cloud AI fallback
  (`AiApiClient`) for open-ended conversation — off by default, nothing leaves the device
  unless you configure it.
- **Actions wired up**: open app (YouTube, Chrome, Maps, WhatsApp, Gmail, Spotify, calendar,
  or any installed app by name), web search, open a website, open Settings pages, flashlight
  on/off, battery status, device info, media play/pause/next/previous, create alarm, create
  reminder (via calendar insert intent), and phone call (**confirmation required**).
- **Confirmation flow**: calls and "delete my data" are parked until you say "yes"/"confirm"
  or tap confirm; anything else is treated as "no".
- **Local memory**: Room database storing preferred name, recent conversation turns (for
  context), and command-usage frequency — all viewable/deletable from Settings.
- **UI**: dark, futuristic Jetpack Compose UI — animated AI core, glowing waveform while
  listening, command history feed, mic button, Settings screen, Permissions screen.
- **Permissions**: requested with a plain-language reason, nothing hidden, least-privilege
  (e.g. `CALL_PHONE` is only ever used after an explicit confirmed call intent).

## 2. What's intentionally stubbed / needs a real key or extra setup

- **Cloud AI for open-ended chit-chat** (`GENERAL_QUESTION` intent): works out of the box in
  a limited offline mode ("I can't answer that yet, but I can open apps / search / etc.").
  To get real conversational answers, wire up `AiApiClient.configure(endpoint, apiKey)` with
  your own Anthropic (or other) API key — see §5.
- **True low-power wake-word detection**: the MVP re-runs `SpeechRecognizer` in a loop inside
  a foreground service, which is simple and fully free but uses more battery than a dedicated
  wake-word engine. See §6 (Future Expansion) for swapping in Picovoice Porcupine or similar
  without touching the rest of the architecture.
- **Calling a contact by name**: `MAKE_CALL` currently dials whatever string it's given as if
  it were a phone number. Add `READ_CONTACTS` + a `ContactsContract` lookup in
  `AndroidActionExecutor.makeCall()` to resolve names to numbers.
- **Reminders**: uses a generic calendar-insert intent (works across most calendar apps) since
  there's no universal cross-OEM "reminders" intent.

## 3. Project structure

```
JarvisAssistant/
├── app/src/main/java/com/jarvis/assistant/
│   ├── JarvisApplication.kt        # shared singletons (memory + router)
│   ├── MainActivity.kt             # Compose nav host + first-run permission request
│   ├── ai/
│   │   ├── AiModels.kt             # JarvisIntent, IntentType, ConversationTurn
│   │   ├── IntentProcessor.kt      # offline rule-based NLU (EN/TA/Tanglish)
│   │   └── AiApiClient.kt          # optional cloud fallback for general questions
│   ├── actions/
│   │   ├── CommandRouter.kt        # orchestrates AI -> confirmation -> execution -> memory
│   │   ├── AndroidActionExecutor.kt# the only class touching real Android system APIs
│   │   └── ConfirmationManager.kt  # holds pending sensitive actions until confirmed
│   ├── voice/
│   │   ├── SpeechToTextManager.kt  # SpeechRecognizer wrapper
│   │   ├── TextToSpeechManager.kt  # TextToSpeech wrapper
│   │   └── JarvisListenerService.kt# optional foreground "Hey Jarvis" listener
│   ├── memory/
│   │   ├── MemoryEntities.kt / MemoryDao.kt / MemoryDatabase.kt   # Room
│   │   └── MemoryRepository.kt     # clean API + "delete all data"
│   ├── ui/
│   │   ├── JarvisTheme.kt, JarvisViewModel.kt
│   │   ├── components/AiCore.kt, CommandHistoryView.kt
│   │   └── screens/MainScreen.kt, SettingsScreen.kt, PermissionsScreen.kt
│   └── utils/PermissionUtils.kt, Constants.kt
└── app/src/main/res/...
```

The layers are deliberately decoupled — **AI layer → Command Router → Android action
layer → UI**, with **memory** and **permissions** as cross-cutting modules — exactly so new
intents, new actions, or a smarter AI model can be dropped in without rewriting the rest.

## 4. Build & run instructions

**Requirements**: Android Studio (Koala or newer recommended), JDK 17, an Android device or
emulator running API 26+ (Android 8.0+).

1. Download/copy the `JarvisAssistant/` folder to your computer.
2. Open Android Studio → **Open** → select the `JarvisAssistant` folder.
3. Let Android Studio sync Gradle (it will generate the Gradle wrapper jar automatically on
   first sync; if you prefer the command line, run `gradle wrapper` once inside the project
   folder first, then use `./gradlew` as usual).
4. Connect a physical device (recommended — the emulator's virtual mic makes voice testing
   awkward) with USB debugging enabled, or start an emulator.
5. Click **Run ▶** or, from the command line:
   ```
   ./gradlew installDebug
   ```
6. On first launch, grant the microphone and camera (flashlight) permissions when prompted —
   each request explains exactly why it's needed.
7. Tap the mic button and say: **"Open YouTube"** — JARVIS should launch YouTube and say
   "Opening YouTube" (or similar) back to you.
8. To try the wake word hands-free, go to **Settings → Continuous "Hey Jarvis" listening** and
   enable it. You'll see a persistent notification while it's active (by design — JARVIS never
   listens invisibly). Say **"Hey Jarvis, open YouTube"**.

## 5. Enabling the cloud AI model (optional)

The offline NLU handles all the structured actions above with zero setup. If you also want
JARVIS to answer arbitrary questions conversationally:

1. Get an API key from your chosen provider (e.g. Anthropic).
2. In `JarvisApplication.onCreate()`, after `commandRouter` is created, call:
   ```kotlin
   commandRouter.configureCloudAi(
       endpoint = "https://api.anthropic.com/v1/messages",
       apiKey = "YOUR_KEY_HERE" // load from a secure source, never commit a real key
   )
   ```
3. Prefer loading the key from `local.properties` (untracked by git) via `BuildConfig`, or
   from Android's `EncryptedSharedPreferences`, rather than hardcoding it.

Until configured, general questions get a clear, honest "I can't answer that yet in offline
mode" response rather than failing silently.

## 6. Future expansion (architecture is ready for these)

The clean separation between voice / AI / actions / memory / UI means each of these can be
added as new modules without breaking existing functionality:

- **n8n / webhook automation** — add a `WEBHOOK` intent type + an `AutomationExecutor` that
  POSTs to an n8n workflow URL.
- **Smart-home / IoT control** — add intents like `SMART_HOME` with a target device + action,
  routed to a Matter/Google Home/Home Assistant client.
- **PC control** — a small companion socket/HTTP server on the PC; add a `PC_CONTROL` intent.
- **Calendar / email automation** — use `CalendarContract` / Gmail API with proper OAuth and
  explicit, itemized permission requests (following the same "never hide permissions" rule).
- **Weather / news** — new `WEATHER` / `NEWS` intents backed by a REST API call.
- **Location-based automation** — `FusedLocationProviderClient` + geofences, requested only
  when the user turns on a specific location-based routine.
- **Custom plugins/tools** — define a small plugin interface (`JarvisPlugin.canHandle(intent)`
  / `execute(intent)`) and let `CommandRouter` consult registered plugins before falling back
  to `GENERAL_QUESTION`.
- **Offline AI model** — swap `AiApiClient` for an on-device model (e.g. via MediaPipe LLM
  Inference or llama.cpp bindings) behind the same interface, so nothing else needs to change.
- **Dedicated wake-word engine** — replace the `SpeechRecognizer`-loop in
  `JarvisListenerService` with Picovoice Porcupine (free tier available) for a true low-power,
  always-on "Hey Jarvis" detector; everything downstream (`CommandRouter` etc.) stays the same.

## 7. Privacy & security notes

- All structured commands are understood **on-device**, with no network call.
- Nothing is sent to a cloud AI unless you explicitly configure one (§5).
- JARVIS never asks for or stores passwords, OTPs, or banking details.
- Sensitive actions (`MAKE_CALL`, `DELETE_MEMORY`) always go through the confirmation flow —
  by voice ("yes"/"no") or by tapping the button in the UI.
- Every requested Android permission shows a plain-language reason before the OS prompt
  (see Permissions screen).
- "Delete my data" in Settings wipes stored preferences, conversation history, and command
  usage stats completely and immediately.

## 8. Known limitations of this MVP

- Wake-word loop uses more battery than a dedicated wake-word engine (see §6).
- No contact-name-to-number resolution for calls yet (dials the literal spoken string).
- Tamil TTS quality depends on the Tamil voice pack being installed on the device
  (Settings → Text-to-speech → Install voice data).
- The rule-based NLU is intentionally simple/extensible rather than a full ML model; add more
  keyword variants in `IntentProcessor.kt` as you discover phrasings it misses.
